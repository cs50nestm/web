const PADDLE_SPEED = 5
const SCALE = 2.3
const VIRTUAL_WIDTH = 960 / SCALE
const VIRTUAL_HEIGHT = 540 / SCALE

let backgroundImg, arrowsImg, arrows, heartsImg, hearts, particle, main, retroFont
let gbricks, bricks, brick, paddles, paddle, balls, ball
let paddleHit, scoreSound, wallHit, confirm, select, noSelect, brickHit1, brickHit2, hurt, victory, recover, highScore, pause, music
let gameState = "start" // start, play, serve, gameOver, victory, highScores, enterHighScore, paddleSelect
let level = 0
let score = 0
let health = 3

function preload() {
    // load graphics
    backgroundImg = loadImage("graphics/background.png")
    main = loadImage("graphics/breakout.png")
    heartsImg = loadImage("graphics/hearts.png")
    arrowsImg = loadImage("graphics/arrows.png")

    // load sounds
    paddleHit = loadSound("sounds/paddle_hit.wav")
    scoreSound = loadSound("sounds/score.wav")
    wallHit = loadSound("sounds/wall_hit.wav")
    confirmSound = loadSound("sounds/confirm.wav")
    select = loadSound("sounds/select.wav")
    noSelect = loadSound("sounds/no-select.wav")
    brickHit1 = loadSound("sounds/brick-hit-1.wav")
    brickHit2 = loadSound("sounds/brick-hit-2.wav")
    hurt = loadSound("sounds/hurt.wav")
    victory = loadSound("sounds/victory.wav")
    recover = loadSound("sounds/recover.wav")
    highScore = loadSound("sounds/high_score.wav")
    pause = loadSound("sounds/pause.wav")
    music = loadSound("sounds/music.wav")

    // load font  
    retroFont = loadFont('fonts/font.ttf')  
}

function setup() {
    createCanvas(960, 540)
}

function draw() {
    // scale all elements by scale factor
    scale(SCALE)
    image(backgroundImg, 0, 0, VIRTUAL_WIDTH + 1, VIRTUAL_HEIGHT + 1)
}

