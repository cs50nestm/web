let player1Score = 0
let player2Score = 0

function preload() {
  fontRetro = loadFont("font.ttf")
}

function setup() {
  createCanvas(800, 500)
}

function draw() {
  background(0)
  dashedLine(25)
  title()
  score()
}

function score() {
  fill(180)
  noStroke()
  textAlign(CENTER)
  textSize(60)
  textFont(fontRetro)
  text(player1Score, width / 4, 80)
  text(player2Score, 3*width / 4, 80)
}

function title() {
  fill(255)
  noStroke()
  textSize(18)
  textFont(fontRetro)
  text("Press Enter to Begin", width / 2, 35)
}

function dashedLine(pixels) {
  stroke(180)
  strokeWeight(2)
  let center = width / 2
  for (let i = 0; i < height / pixels; i++) {
    line(center, i * pixels + 5, center, i * pixels + 15)
  }
}