class Pipe {

}