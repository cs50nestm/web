let BACKGROUND_SCROLL_SPEED = .5
let BACKGROUND_LOOPING_PT = 413
let GROUND_SCROLL_SPEED = 1
let GROUND_LOOPING_SPEED = 438
let SPACE = 32

let bgScroll = 0
let groundScroll = 0
let spawnTimer = 0
let points = 0
let pipes = []
let gameState = "title" // title, countdown, play, done'
let count = 3
let timer = 0

let bgImage, groundImage, birdImage, bird, pipeImage, pipe, lastY
let flappyFont, gameFont, explosion, jump, score, hurt, music

function preload() {

}

function setup() {

}

function draw() {

}

