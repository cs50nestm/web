// Takes tile sheet and returns an array of tiles

