let x, y
let d = 20
let xspeed, yspeed
let lPadX, lPadY, rPadX, rPadY
let padH = 80
let padW = 10
let lScore = 0
let rScore = 0

function setup() {
  createCanvas(600, 400)
}

function draw() {
  background(0)
  dashedLine(25)
  score()
}

function score() {
  fill(255)
  noStroke()
  textAlign(CENTER)
  textSize(32)
  text(lScore, width/4, 50)
  text(rScore, 3*width/4, 50)
}

function dashedLine(pixels) {
  stroke(255)
  strokeWeight(2)
  let center = width / 2
  for (let i = 0; i < height / pixels; i++) {
    line(center, i * pixels + 5, center, i * pixels + 15)
  }
}
