const HEALTHY = 0
const SICK = 1
const RECOVERED = 2
let people = []
let number = 100
let size = 10

function windowResized() {
  let canvasWidth = document.querySelector("#canvas").clientWidth;
  let canvasHeight = (0.635) * canvasWidth
  resizeCanvas(canvasWidth, canvasHeight)
}


function setup() {
  let canvasWidth = document.querySelector("#canvas").clientWidth;
  let canvasHeight = (0.635) * canvasWidth
  let cnv = createCanvas(canvasWidth, canvasHeight)
  cnv.parent("canvas");

}

function draw() {
  background(0)
}